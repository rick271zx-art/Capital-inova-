# Capital Inova RP — Multiplayer (protótipo)

## O que esta versão já faz
- Conexão em tempo real com Socket.IO.
- Jogadores aparecem no mesmo mapa 2D de demonstração.
- Chat compartilhado.
- Trabalhos com recompensas de teste validadas no servidor.
- Painel ADM com checagem no servidor.
- Remoção de um jogador da sessão (não é banimento persistente).

## Rodar no computador
1. Instale Node.js 18 ou superior.
2. Extraia a pasta.
3. Abra um terminal nesta pasta.
4. Rode `npm install`.
5. Configure códigos secretos:
   - Linux/macOS: `OWNER_CODE='seu-codigo-forte' ADMIN_CODE='outro-codigo-forte' npm start`
   - Windows PowerShell: `$env:OWNER_CODE='seu-codigo-forte'; $env:ADMIN_CODE='outro-codigo-forte'; npm start`
6. Abra `http://localhost:3000`.
7. Para testar vários jogadores no mesmo computador, abra o endereço em mais de uma aba. Para celulares na mesma rede, use o IP local do computador e a porta 3000.

## Publicar online
Faça upload desta pasta para um repositório Git e crie um serviço Web Node em um provedor de hospedagem que suporte Node.js e WebSockets. Configure:
- Build command: `npm install`
- Start command: `npm start`
- Environment variables: `OWNER_CODE` e `ADMIN_CODE` com códigos fortes e secretos.

Depois, abra a URL HTTPS fornecida pela hospedagem. Qualquer pessoa com o link poderá tentar entrar; defina regras de comunidade e proteção contra abuso.

## Importante
- Os códigos administrativos são validados no servidor; não coloque segredos no HTML.
- Troque os códigos de exemplo antes de publicar.
- Não há banco de dados nesta versão: dinheiro, jogadores e remoções são temporários e reiniciam quando o servidor reinicia.
- O mapa é um protótipo 2D, não um GTA 3D. Não é uma cópia de assets do GTA ou do LifeAfter/Life Russia.
- Para um jogo público de verdade, implemente autenticação, banco de dados, persistência, logs de auditoria, rate limiting, validação de movimentos e banimentos persistentes.
