const path = require("path");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const PORT = process.env.PORT || 3000;
// Configure these in your hosting provider's Environment Variables.
// Do not publish real admin codes in the frontend.
const OWNER_CODE = process.env.OWNER_CODE || "TROQUE_ESTE_CODIGO";
const ADMIN_CODE = process.env.ADMIN_CODE || "TROQUE_CODIGO_ADM";

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Capital Inova RP" }));

const players = new Map();
const bannedIds = new Set();
const locations = ["Centro", "Praça Central", "Hospital", "Bairro Residencial", "Concessionária"];

function publicPlayer(p) {
  return { id: p.id, name: p.name, x: p.x, y: p.y, location: p.location, role: p.role, money: p.money };
}
function broadcastPlayers() {
  io.emit("players:update", [...players.values()].map(publicPlayer));
}
function system(message) {
  io.emit("chat:message", { system: true, name: "Capital Inova", message, time: Date.now() });
}
function cleanName(value) {
  return String(value || "Jogador").replace(/[<>]/g, "").trim().slice(0, 18) || "Jogador";
}

io.on("connection", (socket) => {
  if (bannedIds.has(socket.id)) {
    socket.emit("notice", "Acesso bloqueado nesta sessão de teste.");
    socket.disconnect(true);
    return;
  }

  const p = {
    id: socket.id,
    name: "Jogador",
    x: 50 + Math.random() * 300,
    y: 70 + Math.random() * 160,
    location: "Centro",
    role: "player",
    money: 15000,
    lastChat: 0
  };
  players.set(socket.id, p);
  socket.emit("session", { id: p.id, player: publicPlayer(p) });
  socket.emit("chat:history", []);
  system(`${p.name} entrou na cidade.`);
  broadcastPlayers();

  socket.on("profile:set", (data = {}) => {
    p.name = cleanName(data.name);
    broadcastPlayers();
    system(`${p.name} entrou na cidade.`);
  });

  socket.on("player:move", (data = {}) => {
    // Basic server-side bounds checks. This is a simple prototype, not anti-cheat-grade.
    const x = Number(data.x), y = Number(data.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return;
    p.x = Math.max(12, Math.min(588, x));
    p.y = Math.max(12, Math.min(288, y));
    if (typeof data.location === "string" && locations.includes(data.location)) p.location = data.location;
    broadcastPlayers();
  });

  socket.on("chat:send", (raw) => {
    const now = Date.now();
    if (now - p.lastChat < 700) return;
    p.lastChat = now;
    const message = String(raw || "").replace(/[<>]/g, "").trim().slice(0, 180);
    if (!message) return;
    io.emit("chat:message", { system: false, name: p.name, message, time: now });
  });

  socket.on("job:complete", (job = {}) => {
    const amount = Math.max(0, Math.min(2500, Math.floor(Number(job.reward) || 0)));
    const allowedJobs = ["Motorista", "Socorrista", "Entregador", "Policial"];
    if (!allowedJobs.includes(String(job.name)) || amount === 0) return;
    p.money += amount;
    socket.emit("player:private", { money: p.money, message: `Trabalho concluído: ${job.name}. +$${amount}` });
    broadcastPlayers();
  });

  socket.on("admin:login", (data = {}) => {
    const code = String(data.code || "");
    if (code === OWNER_CODE && OWNER_CODE !== "TROQUE_ESTE_CODIGO") {
      p.role = "owner";
      socket.emit("admin:result", { ok: true, role: p.role, message: "Acesso ADM CHEFE concedido." });
    } else if (code === ADMIN_CODE && ADMIN_CODE !== "TROQUE_CODIGO_ADM") {
      p.role = "admin";
      socket.emit("admin:result", { ok: true, role: p.role, message: "Acesso ADM concedido." });
    } else {
      socket.emit("admin:result", { ok: false, message: "Código inválido. Configure os códigos no servidor." });
    }
    broadcastPlayers();
  });

  socket.on("admin:command", (data = {}) => {
    if (!["owner", "admin"].includes(p.role)) {
      socket.emit("admin:result", { ok: false, message: "Permissão negada." });
      return;
    }
    const action = String(data.action || "");
    const target = players.get(String(data.target || ""));
    if (action === "money") {
      if (p.role !== "owner") {
        socket.emit("admin:result", { ok: false, message: "Só ADM CHEFE pode alterar saldo." });
        return;
      }
      p.money = 999999999;
      socket.emit("player:private", { money: p.money, message: "Saldo de teste atualizado pelo ADM CHEFE." });
      socket.emit("admin:result", { ok: true, message: "Saldo de teste atualizado." });
    } else if (action === "fly") {
      socket.emit("admin:result", { ok: true, message: "Voo de demonstração ativado. A física do jogo ainda é básica." });
    } else if (action === "locate") {
      socket.emit("admin:result", { ok: true, message: target ? `${target.name}: ${target.location} (posição ${Math.round(target.x)}, ${Math.round(target.y)}).` : "Escolha um jogador online." });
    } else if (action === "ban") {
      if (p.role !== "owner" && p.role !== "admin") return;
      if (!target || target.id === socket.id) {
        socket.emit("admin:result", { ok: false, message: "Escolha outro jogador conectado." });
        return;
      }
      // Prototype ban is in-memory and resets when server restarts.
      bannedIds.add(target.id);
      io.to(target.id).emit("notice", "Você foi removido da sessão pelo administrador.");
      io.sockets.sockets.get(target.id)?.disconnect(true);
      players.delete(target.id);
      socket.emit("admin:result", { ok: true, message: `${target.name} removido desta sessão de teste. O banimento não é persistente.` });
      broadcastPlayers();
    } else if (action === "item") {
      socket.emit("admin:result", { ok: true, message: "Item de demonstração adicionado (inventário ainda não persistente)." });
    } else if (action === "salary") {
      p.money += 5000000;
      socket.emit("player:private", { money: p.money, message: "Recompensa de teste: +$5.000.000." });
      socket.emit("admin:result", { ok: true, message: "Recompensa de teste aplicada manualmente; não há temporizador de 10 dias nesta versão." });
      broadcastPlayers();
    } else {
      socket.emit("admin:result", { ok: false, message: "Comando desconhecido." });
    }
  });

  socket.on("disconnect", () => {
    const name = p.name;
    players.delete(socket.id);
    system(`${name} saiu da cidade.`);
    broadcastPlayers();
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`Capital Inova RP rodando na porta ${PORT}`));
